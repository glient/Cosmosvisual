package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.WorldDraw;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;

/** Coloured hitbox of other players (players only). */
public class HitboxesModule implements PulseModule {
    @Override
    public void world(WorldRenderContext ctx, float delta) {
        if (!Pulse.on("hitboxes")) return;
        var mc = Pulse.mc();
        int col = Pulse.color("hitboxes");
        float op = Pulse.v("hitboxes", "opacity");
        int layers = (int) Pulse.v("hitboxes", "thickness");
        for (AbstractClientPlayerEntity pl : mc.world.getPlayers()) {
            if (pl == mc.player || pl.isInvisible() && pl.isSpectator()) continue;
            if (pl.squaredDistanceTo(mc.player) > 96 * 96) continue;
            WorldDraw.thickBox(ctx, Boxes.lerp(pl, delta), col, op, layers);
        }
    }
}
