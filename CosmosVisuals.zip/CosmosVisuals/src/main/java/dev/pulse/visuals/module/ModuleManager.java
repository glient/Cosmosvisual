package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Owns all modules and forwards events. A module that throws is switched off for the session instead of crashing the game. */
public final class ModuleManager {
    private static final List<PulseModule> MODULES = new ArrayList<>();
    private static final Set<PulseModule> BROKEN = new HashSet<>();

    public static void init() {
        MODULES.add(new TargetHudModule());
        MODULES.add(new PotionTimerModule());
        MODULES.add(new TotemAlertModule());
        MODULES.add(new TargetOutlineModule());

        MODULES.add(new ArmorMonitorModule());
        MODULES.add(new ResourceTrackerModule());
        MODULES.add(new LowHpPulseModule());
        MODULES.add(new AttackDirectionModule());

        MODULES.add(new AttackCooldownModule());
        MODULES.add(new CrosshairFeedbackModule());
        MODULES.add(new DamageNumbersModule());
        MODULES.add(new HitCounterModule());
        MODULES.add(new TrajectoryModule());

        MODULES.add(new HitboxesModule());
        MODULES.add(new FullbrightModule());
        MODULES.add(new ZoomModule());
        MODULES.add(new ToggleSprintModule());
        MODULES.add(new StretchModule());

        MODULES.add(new TrainingModule());
    }

    private static void fail(PulseModule m, Throwable t) {
        if (BROKEN.add(m)) Pulse.LOGGER.error("Module " + m.getClass().getSimpleName() + " crashed and was disabled for this session", t);
    }

    public static void tick(MinecraftClient c) {
        try {
            TargetTracker.tick(c);
            CombatEvents.tick(c);
        } catch (Throwable t) {
            Pulse.LOGGER.error("Tracker error", t);
        }
        for (PulseModule m : MODULES) {
            if (BROKEN.contains(m)) continue;
            try { m.tick(c); } catch (Throwable t) { fail(m, t); }
        }
    }

    public static void hud(DrawContext g, float delta) {
        Pulse.frame();
        MinecraftClient c = Pulse.mc();
        if (c.player == null || c.world == null) return;
        for (PulseModule m : MODULES) {
            if (BROKEN.contains(m)) continue;
            try { m.hud(g, delta); } catch (Throwable t) { fail(m, t); }
        }
    }

    public static void world(WorldRenderContext ctx) {
        MinecraftClient c = Pulse.mc();
        if (c.player == null || c.world == null) return;
        float delta = c.getRenderTickCounter().getTickProgress(false);
        for (PulseModule m : MODULES) {
            if (BROKEN.contains(m)) continue;
            try { m.world(ctx, delta); } catch (Throwable t) { fail(m, t); }
        }
    }

    public static void reset() {
        TargetTracker.reset();
        CombatEvents.reset();
        for (PulseModule m : MODULES) {
            try { m.reset(); } catch (Throwable ignored) {}
        }
    }

    private ModuleManager() {}
}
