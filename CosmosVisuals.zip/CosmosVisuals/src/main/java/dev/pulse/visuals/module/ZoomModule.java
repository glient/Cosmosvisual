package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.PulseVisualsClient;
import net.minecraft.client.MinecraftClient;

/** Hold the Zoom key (default C) to zoom. Works by smoothly lowering the FOV option and restoring it afterwards. */
public class ZoomModule implements PulseModule {
    private boolean zooming;
    private int saved;
    private float cur;

    @Override
    public void tick(MinecraftClient c) {
        var opt = c.options.getFov();
        boolean want = Pulse.on("zoom") && c.player != null && c.currentScreen == null && PulseVisualsClient.ZOOM_KEY.isPressed();
        if (want) {
            if (!zooming) { zooming = true; saved = opt.getValue(); cur = saved; }
            float target = Math.max(30f, saved / Pulse.v("zoom", "factor"));
            cur += (target - cur) * 0.4f;
            opt.setValue(Math.round(cur));
        } else if (zooming) {
            cur += (saved - cur) * 0.5f;
            if (Math.abs(saved - cur) < 1.5f) { opt.setValue(saved); zooming = false; }
            else opt.setValue(Math.round(cur));
        }
    }

    @Override
    public void reset() { zooming = false; }
}
