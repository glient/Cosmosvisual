package dev.pulse.visuals.config;

import java.util.LinkedHashMap;
import java.util.Map;

/** Saved state of one module (what ends up in pulsevisuals.json). */
public final class ModuleState {
    public boolean enabled;
    public int color;
    public Map<String, Float> values = new LinkedHashMap<>();
}
