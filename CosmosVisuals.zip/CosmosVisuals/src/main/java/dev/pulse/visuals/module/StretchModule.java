package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import net.minecraft.client.MinecraftClient;

/** Holds the smoothed stretch factor that GameRendererMixin applies to the projection matrix. */
public class StretchModule implements PulseModule {
    private static float current = 1f;

    public static float factor() { return current; }
    public static boolean active() { return Math.abs(current - 1f) > 0.002f; }

    @Override
    public void tick(MinecraftClient c) {
        float target = Pulse.on("stretch") ? Pulse.v("stretch", "factor") : 1f;
        current += (target - current) * 0.25f;
        if (Math.abs(target - current) < 0.002f) current = target;
    }
}
