package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;

import java.util.Random;

/** Purely cosmetic crit sparks, spawned client-side only (the server never sees them). */
public final class HitParticlesModule {
    private static final Random RND = new Random();

    public static void spawn(Entity e) {
        var w = Pulse.mc().world;
        if (w == null) return;
        int n = (int) Pulse.v("hit_particles", "count");
        for (int i = 0; i < n; i++) {
            w.addParticleClient(ParticleTypes.CRIT,
                    e.getX() + (RND.nextDouble() - 0.5) * e.getWidth(),
                    e.getBodyY(0.3 + RND.nextDouble() * 0.6),
                    e.getZ() + (RND.nextDouble() - 0.5) * e.getWidth(),
                    (RND.nextDouble() - 0.5) * 0.6, RND.nextDouble() * 0.4, (RND.nextDouble() - 0.5) * 0.6);
        }
    }

    private HitParticlesModule() {}
}
