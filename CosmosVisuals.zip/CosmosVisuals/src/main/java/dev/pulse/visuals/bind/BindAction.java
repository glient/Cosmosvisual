package dev.pulse.visuals.bind;

public enum BindAction {
    COMMAND("Чат-команда"),
    CHAT_MESSAGE("Сообщение в чат"),
    TOGGLE_FEATURE("Функция мода"),
    OPEN_TAB("Открыть вкладку"),
    HOTBAR_SLOT("Слот хотбара");

    public final String label;
    BindAction(String label) { this.label = label; }

    public BindAction next() { return values()[(ordinal() + 1) % values().length]; }

    public String defaultParam() {
        return switch (this) {
            case COMMAND -> "";
            case CHAT_MESSAGE -> "gg";
            case TOGGLE_FEATURE -> "hitboxes";
            case OPEN_TAB -> "COMBAT";
            case HOTBAR_SLOT -> "1";
        };
    }
}
