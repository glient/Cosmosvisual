package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import dev.pulse.visuals.util.Sfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvents;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Big text + sound when somebody else pops a totem. onPop() is called from ClientPlayNetworkHandlerMixin (status 35). */
public class TotemAlertModule implements PulseModule {
    private record Pop(String name, long time) {}
    private static final List<Pop> POPS = new CopyOnWriteArrayList<>();

    public static void onPop(Entity e) {
        var c = Pulse.mc();
        if (c.player == null || e == c.player || !Pulse.on("totem_alert")) return;
        POPS.add(new Pop(e.getName().getString(), System.currentTimeMillis()));
        float vol = Pulse.v("totem_alert", "volume");
        Sfx.play(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, vol);
        Sfx.play(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, vol);
    }

    @Override
    public void hud(DrawContext g, float delta) {
        if (POPS.isEmpty()) return;
        long now = System.currentTimeMillis();
        float life = Pulse.v("totem_alert", "life");
        float size = Pulse.v("totem_alert", "size");
        float op = Pulse.v("totem_alert", "opacity");
        int col = Pulse.color("totem_alert");
        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();
        int i = 0;
        for (Pop p : POPS) {
            float age = (now - p.time()) / 1000f;
            if (age > life) { POPS.remove(p); continue; }
            float fadeIn = Anim.clamp(age / 0.12f);
            float fadeOut = Anim.clamp((life - age) / 0.4f);
            float al = Math.min(fadeIn, fadeOut) * op;
            if (i == 0 && age < 0.25f) g.fill(0, 0, w, h, Gfx.argb(0.14f * (1f - age / 0.25f) * op, col)); // quick flash
            String s = "TOTEM POP  " + p.name();
            float sc = size * (1f + 0.25f * (1f - fadeIn));
            float x = (w - Gfx.tw(s) * sc) / 2f;
            float y = h * 0.28f + i * 14f * size;
            Gfx.stext(g, s, x, y, sc, Gfx.argb(al, col));
            i++;
        }
    }

    @Override
    public void reset() { POPS.clear(); }
}
