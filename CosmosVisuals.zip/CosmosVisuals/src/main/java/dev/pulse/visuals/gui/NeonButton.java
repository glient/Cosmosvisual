package dev.pulse.visuals.gui;

import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** ButtonWidget with the neon look. */
public class NeonButton extends ButtonWidget {
    public NeonButton(int x, int y, int w, int h, Text msg, PressAction onPress) {
        super(x, y, w, h, msg, onPress, DEFAULT_NARRATION_SUPPLIER);
    }

    @Override
    public void renderWidget(DrawContext g, int mouseX, int mouseY, float delta) {
        boolean hov = isHovered() && active;
        int accent = PulseScreen.ACCENT;
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        Gfx.rect(g, x, y, w, h, Gfx.argb(hov ? 0.9f : 0.75f, hov ? 0x201B38 : 0x12121C));
        Gfx.border(g, x, y, w, h, Gfx.argb(hov ? 0.95f : 0.45f, accent));
        if (hov) Gfx.glow(g, x, y, w, h, accent, 0.8f);
        String s = Gfx.tr().trimToWidth(getMessage().getString(), w - 8);
        Gfx.ctext(g, s, x + w / 2, y + (h - 8) / 2, active ? 0xFFFFFFFF : 0x66FFFFFF);
    }
}
