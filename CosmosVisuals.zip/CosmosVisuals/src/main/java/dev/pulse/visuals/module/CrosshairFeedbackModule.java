package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.gui.DrawContext;

/**
 * Recolours the crosshair when the vanilla hitbox raycast (client.targetedEntity) is on a living entity.
 * We draw a coloured overlay at the exact screen centre, so the crosshair never moves and no mixin is needed.
 */
public class CrosshairFeedbackModule implements PulseModule {
    private float a;

    @Override
    public void hud(DrawContext g, float delta) {
        var mc = Pulse.mc();
        boolean on = Pulse.on("crosshair_feedback") && mc.currentScreen == null && mc.options.getPerspective().isFirstPerson();
        boolean hit = on && mc.targetedEntity instanceof net.minecraft.entity.LivingEntity;
        a = Anim.step(a, hit ? 1f : 0f, Pulse.dt * 10f);
        if (a <= 0.02f) return;
        int col = Pulse.color("crosshair_feedback");
        float op = Pulse.v("crosshair_feedback", "opacity") * a;
        float s = Pulse.v("crosshair_feedback", "size");
        int cx = g.getScaledWindowWidth() / 2, cy = g.getScaledWindowHeight() / 2;
        int gap = Math.round(2 * s), len = Math.max(2, Math.round(5 * s));
        int c = Gfx.argb(op, col);
        g.fill(cx - gap - len, cy, cx - gap, cy + 1, c);   // left
        g.fill(cx + gap + 1, cy, cx + gap + 1 + len, cy + 1, c); // right
        g.fill(cx, cy - gap - len, cx + 1, cy - gap, c);   // up
        g.fill(cx, cy + gap + 1, cx + 1, cy + gap + 1 + len, c); // down
        g.fill(cx, cy, cx + 1, cy + 1, c);
    }
}
