package dev.pulse.visuals.mixin;

import dev.pulse.visuals.module.StretchModule;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Screen Stretch: multiplies the horizontal scale of the 3D projection matrix, so the world looks stretched sideways
 * and the picture runs past the left/right screen edges. The GUI is not touched.
 * require = 0: if this method name changes in a future Yarn build the mod still loads, only the stretch does nothing.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true, require = 0)
    private void pulsevisuals$stretch(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
        if (!StretchModule.active()) return;
        cir.setReturnValue(new Matrix4f().scale(StretchModule.factor(), 1f, 1f).mul(cir.getReturnValue()));
    }
}
