package dev.pulse.visuals.gui;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.bind.BindAction;
import dev.pulse.visuals.bind.BindEntry;
import dev.pulse.visuals.bind.KeybindManager;
import dev.pulse.visuals.config.Defs;
import dev.pulse.visuals.config.ModuleDef;
import dev.pulse.visuals.config.ModuleDef.Tab;
import dev.pulse.visuals.config.ModuleState;
import dev.pulse.visuals.module.TrainingModule;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The Cosmos Visuals menu. Background blur comes from the vanilla Screen.renderBackground (strength = the
 * "Menu Background Blurriness" video setting). Everything else is drawn by hand in renderBackground(),
 * so ButtonWidget / TextFieldWidget are rendered on top of it by Screen.render().
 */
public class PulseScreen extends Screen {
    public static Tab lastTab = Tab.TARGET;
    public static final int ACCENT = 0x9B6BFF;
    private static final int SIDE_W = 84;

    private static final int K_TAB = 0, K_TOGGLE = 1, K_EXPAND = 2, K_SLIDER = 3, K_COLOR = 4, K_BIND = 5;

    private record Region(int x, int y, int w, int h, int kind, ModuleDef def, String key, int idx) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private Tab tab;
    private float openAnim, tabAnim = 1f, frameDt = 0.016f;
    private long lastNs = System.nanoTime();
    private final Map<String, Float> togAnim = new HashMap<>();
    private final Set<String> expanded = new HashSet<>();
    private float scroll, scrollMax, bindScroll;
    private int px, py, pw, ph, cx, cy, cw, ch;

    private final List<Region> regions = new ArrayList<>();
    private Region drag;

    // binds tab state
    private int sel = -1;
    private boolean capturing;
    private NeonButton bindBtn, typeBtn, modeBtn, paramBtn, addBtn, delBtn, spawnBtn, tpBtn, killBtn, resetBtn;
    private TextFieldWidget paramField;

    public PulseScreen(Tab t) {
        super(Text.literal("Cosmos Visuals"));
        this.tab = (t == Tab.TRAINING && !Pulse.singleplayer()) ? Tab.TARGET : t;
        lastTab = this.tab;
    }

    private List<Tab> tabs() {
        List<Tab> l = new ArrayList<>(List.of(Tab.TARGET, Tab.SELF, Tab.COMBAT, Tab.MISC, Tab.BINDS));
        if (Pulse.singleplayer()) l.add(Tab.TRAINING);   // hidden on servers
        return l;
    }

    // ------------------------------------------------------------------ init / widgets
    @Override
    protected void init() {
        pw = Math.min(width - 16, 450);
        ph = Math.min(height - 16, 292);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + SIDE_W + 10;
        cy = py + 30;
        cw = pw - SIDE_W - 18;
        ch = ph - 38;
        int listW = (int) (cw * 0.5f);
        int ex = cx + listW + 10, ew = cw - listW - 10;

        bindBtn = addDrawableChild(new NeonButton(ex, cy + 12, ew, 16, Text.empty(), b -> capturing = true));
        typeBtn = addDrawableChild(new NeonButton(ex, cy + 38, ew, 16, Text.empty(), b -> {
            BindEntry e = selBind();
            if (e == null) return;
            e.action = e.action.next();
            e.param = e.action.defaultParam();
            paramField.setText(e.param);
            Pulse.cfg.markDirty();
        }));
        modeBtn = addDrawableChild(new NeonButton(ex, cy + 64, ew, 16, Text.empty(), b -> {
            BindEntry e = selBind();
            if (e == null) return;
            e.mode = e.mode.next();
            Pulse.cfg.markDirty();
        }));
        paramBtn = addDrawableChild(new NeonButton(ex, cy + 90, ew, 16, Text.empty(), b -> {
            BindEntry e = selBind();
            if (e != null) cycleParam(e);
        }));
        paramField = new TextFieldWidget(textRenderer, ex, cy + 90, ew, 16, Text.empty());
        paramField.setMaxLength(256);
        paramField.setPlaceholder(Text.literal("/spawn; /home  или  gg"));
        paramField.setChangedListener(s -> {
            BindEntry e = selBind();
            if (e != null && isText(e)) { e.param = s; Pulse.cfg.markDirty(); }
        });
        addDrawableChild(paramField);

        addBtn = addDrawableChild(new NeonButton(cx, cy + ch - 18, listW / 2 - 2, 16, Text.literal("+ Добавить"), b -> {
            BindEntry e = new BindEntry();
            Pulse.cfg.binds.add(e);
            sel = Pulse.cfg.binds.size() - 1;
            paramField.setText("");
            Pulse.cfg.markDirty();
        }));
        delBtn = addDrawableChild(new NeonButton(cx + listW / 2 + 2, cy + ch - 18, listW / 2 - 2, 16, Text.literal("Удалить"), b -> {
            if (selBind() == null) return;
            Pulse.cfg.binds.remove(sel);
            sel = Math.min(sel, Pulse.cfg.binds.size() - 1);
            capturing = false;
            if (selBind() != null && isText(selBind())) paramField.setText(selBind().param);
            Pulse.cfg.markDirty();
        }));

        int bw = (cw - 14) / 4;
        spawnBtn = addDrawableChild(new NeonButton(cx, cy, bw, 16, Text.literal("Spawn dummy"), b -> TrainingModule.spawnDummy()));
        tpBtn = addDrawableChild(new NeonButton(cx + bw + 3, cy, bw, 16, Text.literal("TP to dummy"), b -> TrainingModule.teleportToDummy()));
        killBtn = addDrawableChild(new NeonButton(cx + 2 * (bw + 3), cy, bw, 16, Text.literal("Remove dummy"), b -> TrainingModule.removeDummies()));
        resetBtn = addDrawableChild(new NeonButton(cx + 3 * (bw + 3), cy, bw, 16, Text.literal("Reset stats"), b -> TrainingModule.resetStats()));

        if (selBind() != null && isText(selBind())) paramField.setText(selBind().param);
        syncWidgets();
    }

    private BindEntry selBind() {
        return (sel >= 0 && sel < Pulse.cfg.binds.size()) ? Pulse.cfg.binds.get(sel) : null;
    }

    private static boolean isText(BindEntry b) {
        return b.action == BindAction.COMMAND || b.action == BindAction.CHAT_MESSAGE;
    }

    private static List<String> featureIds() {
        List<String> l = new ArrayList<>();
        for (ModuleDef d : Defs.ALL) if (d.tab != Tab.TRAINING || Pulse.singleplayer()) l.add(d.id);
        return l;
    }

    private void cycleParam(BindEntry e) {
        switch (e.action) {
            case TOGGLE_FEATURE -> {
                List<String> ids = featureIds();
                int i = ids.indexOf(e.param);
                e.param = ids.get((i + 1) % ids.size());
            }
            case OPEN_TAB -> {
                Tab[] ts = {Tab.TARGET, Tab.SELF, Tab.COMBAT, Tab.MISC, Tab.BINDS};
                int i = 0;
                for (int k = 0; k < ts.length; k++) if (ts[k].name().equals(e.param)) i = k;
                e.param = ts[(i + 1) % ts.length].name();
            }
            case HOTBAR_SLOT -> {
                int n;
                try { n = Integer.parseInt(e.param.trim()); } catch (Exception ex) { n = 0; }
                e.param = String.valueOf(n % 9 + 1);
            }
            default -> {}
        }
        Pulse.cfg.markDirty();
    }

    private String paramLabel(BindEntry e) {
        return switch (e.action) {
            case TOGGLE_FEATURE -> {
                ModuleDef d = Defs.get(e.param);
                yield "Переключить: " + (d == null ? e.param : d.name);
            }
            case OPEN_TAB -> {
                String t;
                try { t = Tab.valueOf(e.param).title; } catch (Exception ex) { t = e.param; }
                yield "Вкладка: " + t;
            }
            case HOTBAR_SLOT -> "Слот: " + e.param;
            default -> e.param;
        };
    }

    private void syncWidgets() {
        boolean ready = openAnim > 0.95f;
        boolean binds = ready && tab == Tab.BINDS;
        BindEntry b = selBind();
        boolean has = binds && b != null;
        bindBtn.visible = typeBtn.visible = modeBtn.visible = has;
        boolean txt = has && isText(b);
        paramField.visible = txt;
        if (!txt) paramField.setFocused(false);
        paramBtn.visible = has && !txt;
        addBtn.visible = delBtn.visible = binds;
        delBtn.active = has;
        boolean tr = ready && tab == Tab.TRAINING;
        spawnBtn.visible = tpBtn.visible = killBtn.visible = resetBtn.visible = tr;
        if (has) {
            bindBtn.setMessage(Text.literal(capturing ? "Нажми клавишу… (Esc)" : "Забиндить…  [" + KeybindManager.keyName(b.key) + "]"));
            typeBtn.setMessage(Text.literal("Действие: " + b.action.label));
            modeBtn.setMessage(Text.literal("Режим: " + b.mode.label));
            paramBtn.setMessage(Text.literal(paramLabel(b)));
        }
    }

    @Override
    public void tick() { syncWidgets(); }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        lastTab = tab;
        Pulse.cfg.saveIfDirty();
    }

    // ------------------------------------------------------------------ input
    @Override
    public boolean keyPressed(KeyInput input) {
        int k = input.key();
        if (capturing) {
            BindEntry b = selBind();
            if (k == GLFW.GLFW_KEY_ESCAPE) { capturing = false; return true; }
            if (b != null) {
                b.key = (k == GLFW.GLFW_KEY_DELETE || k == GLFW.GLFW_KEY_BACKSPACE) ? -1 : k;
                Pulse.cfg.markDirty();
            }
            capturing = false;
            return true;
        }
        boolean typing = paramField != null && paramField.visible && paramField.isFocused();
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT && !typing) { close(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (capturing) { capturing = false; return true; }
        if (super.mouseClicked(click, doubled)) return true;
        if (click.button() != 0) return false;
        double mx = click.x(), my = click.y();
        for (Region r : regions) {
            if (!r.in(mx, my)) continue;
            switch (r.kind) {
                case K_TAB -> {
                    Tab t = tabs().get(r.idx);
                    if (t != tab) { tab = t; lastTab = t; tabAnim = 0f; scroll = 0f; capturing = false; }
                }
                case K_TOGGLE -> {
                    ModuleState st = Pulse.cfg.state(r.def.id);
                    st.enabled = !st.enabled;
                    Pulse.cfg.markDirty();
                }
                case K_EXPAND -> { if (!expanded.remove(r.def.id)) expanded.add(r.def.id); }
                case K_SLIDER, K_COLOR -> { drag = r; applySlider(r, mx); }
                case K_BIND -> {
                    sel = r.idx;
                    capturing = false;
                    BindEntry b = selBind();
                    if (b != null && isText(b)) paramField.setText(b.param);
                }
                default -> {}
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (drag != null) { applySlider(drag, click.x()); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        drag = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (tab == Tab.BINDS) bindScroll = Math.max(0, bindScroll - (float) v);
        else scroll = Math.max(0, Math.min(scrollMax, scroll - (float) v * 18f));
        return true;
    }

    private void applySlider(Region r, double mx) {
        float t = Anim.clamp((float) ((mx - r.x) / r.w));
        ModuleState st = Pulse.cfg.state(r.def.id);
        if (r.kind == K_COLOR) {
            int v = Math.round(t * 255f);
            int shift = switch (r.key) { case "r" -> 16; case "g" -> 8; default -> 0; };
            st.color = (st.color & ~(0xFF << shift)) | (v << shift);
        } else {
            for (ModuleDef.Slider s : r.def.sliders) {
                if (!s.key().equals(r.key)) continue;
                float v = s.min() + t * (s.max() - s.min());
                v = s.integer() ? Math.round(v) : Math.round(v * 100f) / 100f;
                st.values.put(s.key(), v);
            }
        }
        Pulse.cfg.markDirty();
    }

    // ------------------------------------------------------------------ rendering
    private void addRegion(int x, int y, int w, int h, int kind, ModuleDef d, String key, int idx, boolean clip) {
        if (clip) {
            if (y + h <= cy || y >= cy + ch) return;
            int ny = Math.max(y, cy), nh = Math.min(y + h, cy + ch) - ny;
            y = ny; h = nh;
        }
        regions.add(new Region(x, y, w, h, kind, d, key, idx));
    }

    @Override
    public void renderBackground(DrawContext g, int mx, int my, float delta) {
        super.renderBackground(g, mx, my, delta);            // vanilla blur + darkening

        long n = System.nanoTime();
        frameDt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;
        openAnim = Anim.step(openAnim, 1f, frameDt * 5f);
        tabAnim = Anim.step(tabAnim, 1f, frameDt * 6f);
        regions.clear();

        float oa = Anim.ease(openAnim);
        int yo = Math.round((1f - oa) * 14f);
        int y0 = py + yo;

        // main panel + sidebar
        Gfx.glow(g, px, y0, pw, ph, ACCENT, oa * 0.6f);
        Gfx.rect(g, px, y0, pw, ph, Gfx.argb(oa * 0.84f, 0x0A0A12));
        Gfx.rect(g, px, y0, SIDE_W, ph, Gfx.argb(oa * 0.55f, 0x05050A));
        Gfx.border(g, px, y0, pw, ph, Gfx.argb(oa * 0.7f, ACCENT));
        Gfx.rect(g, px + SIDE_W, y0 + 1, 1, ph - 2, Gfx.argb(oa * 0.35f, ACCENT));

        // title, pulsing a little
        float pulse = (float) (Math.sin(System.nanoTime() / 1e9 * 2.2) * 0.5 + 0.5);
        Gfx.stext(g, "COSMOS", px + 12, y0 + 10, 1.6f, Gfx.argb(oa, Gfx.mix(ACCENT, 0xFFFFFF, 0.15f * pulse)));
        Gfx.text(g, "visuals", px + 13, y0 + 23, Gfx.argb(oa * 0.6f, ACCENT));

        // tabs
        List<Tab> ts = tabs();
        for (int i = 0; i < ts.size(); i++) {
            int tx = px + 6, ty = y0 + 42 + i * 24, tw = SIDE_W - 12, th = 20;
            boolean active = ts.get(i) == tab;
            boolean hover = mx >= tx && mx < tx + tw && my >= ty && my < ty + th;
            if (active) {
                Gfx.rect(g, tx, ty, tw, th, Gfx.argb(oa * 0.28f, ACCENT));
                Gfx.rect(g, tx, ty, 2, th, Gfx.argb(oa, ACCENT));
                Gfx.glow(g, tx, ty, tw, th, ACCENT, oa * 0.5f);
            } else if (hover) {
                Gfx.rect(g, tx, ty, tw, th, Gfx.argb(oa * 0.12f, ACCENT));
            }
            Gfx.text(g, ts.get(i).title, tx + 10, ty + 6, Gfx.argb(oa, active ? 0xFFFFFF : hover ? 0xD8CCFF : 0x9A94B8));
            addRegion(tx, ty, tw, th, K_TAB, null, null, i, false);
        }

        // content
        float ta = Anim.ease(tabAnim);
        float alpha = oa * ta;
        int xo = Math.round((1f - ta) * 12f);
        Gfx.text(g, tab.title.toUpperCase(), cx + xo, y0 + 10, Gfx.argb(alpha, ACCENT));
        Gfx.rect(g, cx + xo, y0 + 22, cw, 1, Gfx.argb(alpha * 0.35f, ACCENT));

        // shift the content area with the open animation (regions must match what is drawn)
        int saveCy = cy;
        cy = saveCy + yo;
        if (tab == Tab.BINDS) drawBinds(g, mx, my, alpha, xo);
        else drawModules(g, mx, my, alpha, xo, tab == Tab.TRAINING ? 22 : 0);
        cy = saveCy;
    }

    private void drawModules(DrawContext g, int mx, int my, float alpha, int xo, int yTop) {
        List<ModuleDef> defs = Defs.forTab(tab);
        scroll = Math.max(0, Math.min(scrollMax, scroll));
        int top = cy - Math.round(scroll) + yTop;
        int y = top;
        int cardW = cw - 8;
        int x = cx + xo;

        if (tab == Tab.TRAINING) {
            Gfx.text(g, "Singleplayer only. Disabled automatically on servers.", x + 2, cy + 20, Gfx.argb(alpha * 0.55f, 0xFFFFFF));
            top += 10;
            y += 10;
        }

        g.enableScissor(cx - 4, cy, cx + cw + 4, cy + ch);
        for (ModuleDef d : defs) {
            ModuleState st = Pulse.cfg.state(d.id);
            boolean exp = expanded.contains(d.id);
            int rows = (d.hasColor ? 3 : 0) + d.sliders.size();
            int cardH = 22 + (exp && rows > 0 ? rows * 14 + 8 : 0);

            float t = togAnim.getOrDefault(d.id, st.enabled ? 1f : 0f);
            t = Anim.step(t, st.enabled ? 1f : 0f, frameDt * 8f);
            togAnim.put(d.id, t);

            int accent = d.hasColor ? (st.color & 0xFFFFFF) : ACCENT;
            Gfx.rect(g, x, y, cardW, cardH, Gfx.argb(alpha * 0.6f, 0x12121C));
            Gfx.border(g, x, y, cardW, cardH, Gfx.argb(alpha * (0.2f + 0.45f * t), ACCENT));
            if (t > 0.05f) Gfx.glow(g, x, y, cardW, cardH, ACCENT, alpha * t * 0.35f);

            Gfx.text(g, d.name, x + 8, y + 7, Gfx.argb(alpha, Gfx.mix(0xB8B2D8, 0xFFFFFF, t)));
            Gfx.text(g, exp ? "v" : ">", x + cardW - 62, y + 7, Gfx.argb(alpha * 0.6f, 0xFFFFFF));
            if (d.hasColor) Gfx.rect(g, x + cardW - 50, y + 7, 8, 8, Gfx.argb(alpha, st.color));

            // toggle pill
            int tx = x + cardW - 34, ty = y + 5;
            Gfx.rect(g, tx, ty, 26, 12, Gfx.argb(alpha, Gfx.mix(0x2A2A3A, ACCENT, t)));
            if (t > 0.05f) Gfx.glow(g, tx, ty, 26, 12, ACCENT, alpha * t);
            Gfx.rect(g, tx + 2 + 14 * t, ty + 2, 8, 8, Gfx.argb(alpha, Gfx.mix(0x8A87A0, 0xFFFFFF, t)));
            addRegion(tx, ty, 26, 12, K_TOGGLE, d, null, 0, true);
            addRegion(x, y, cardW - 38, 22, K_EXPAND, d, null, 0, true);

            if (exp && rows > 0) {
                int ry = y + 26;
                if (d.hasColor) {
                    String[] keys = {"r", "g", "b"};
                    int[] shifts = {16, 8, 0};
                    int[] cols = {0xFF4D6D, 0x3CFF8A, 0x4DA3FF};
                    for (int i = 0; i < 3; i++) {
                        int v = (st.color >> shifts[i]) & 255;
                        drawSlider(g, x, ry, cardW, "Color " + keys[i].toUpperCase(), v / 255f, String.valueOf(v), cols[i], alpha, K_COLOR, d, keys[i]);
                        ry += 14;
                    }
                }
                for (ModuleDef.Slider s : d.sliders) {
                    float v = Pulse.cfg.val(d.id, s.key());
                    String txt = s.integer() ? String.valueOf(Math.round(v)) : String.format(java.util.Locale.ROOT, "%.2f", v);
                    drawSlider(g, x, ry, cardW, s.label(), (v - s.min()) / (s.max() - s.min()), txt, accent, alpha, K_SLIDER, d, s.key());
                    ry += 14;
                }
            }
            y += cardH + 4;
        }
        g.disableScissor();
        scrollMax = Math.max(0, (y - top) + yTop - ch + 4);
    }

    private void drawSlider(DrawContext g, int x, int y, int w, String label, float frac, String val, int col,
                            float alpha, int kind, ModuleDef d, String key) {
        frac = Anim.clamp(frac);
        Gfx.text(g, label, x + 10, y + 3, Gfx.argb(alpha * 0.8f, 0xCFCBE6));
        int bx = x + 104, bw = w - 104 - 44;
        Gfx.rect(g, bx, y + 5, bw, 4, Gfx.argb(alpha * 0.9f, 0x2A2A3A));
        Gfx.rect(g, bx, y + 5, bw * frac, 4, Gfx.argb(alpha, col));
        Gfx.rect(g, bx + bw * frac - 2, y + 3, 4, 8, Gfx.argb(alpha, 0xFFFFFF));
        Gfx.text(g, val, x + w - 8 - Gfx.tw(val), y + 3, Gfx.argb(alpha, 0xFFFFFF));
        addRegion(bx, y, bw, 14, kind, d, key, 0, true);
    }

    private void drawBinds(DrawContext g, int mx, int my, float alpha, int xo) {
        List<BindEntry> bs = Pulse.cfg.binds;
        int x = cx + xo;
        int listW = (int) (cw * 0.5f);
        int listH = ch - 22;
        int rowH = 16;
        int vis = Math.max(1, (listH - 4) / rowH);
        bindScroll = Math.max(0, Math.min(Math.max(0, bs.size() - vis), bindScroll));

        Gfx.rect(g, x, cy, listW, listH, Gfx.argb(alpha * 0.55f, 0x0E0E18));
        Gfx.border(g, x, cy, listW, listH, Gfx.argb(alpha * 0.4f, ACCENT));
        if (bs.isEmpty()) Gfx.text(g, "Нет биндов. Нажми «+ Добавить»", x + 8, cy + 8, Gfx.argb(alpha * 0.6f, 0xFFFFFF));

        for (int i = 0; i < vis; i++) {
            int idx = (int) bindScroll + i;
            if (idx >= bs.size()) break;
            BindEntry b = bs.get(idx);
            int ry = cy + 2 + i * rowH;
            boolean selected = idx == sel;
            boolean hover = mx >= x && mx < x + listW && my >= ry && my < ry + rowH;
            if (selected) {
                Gfx.rect(g, x + 1, ry, listW - 2, rowH, Gfx.argb(alpha * 0.3f, ACCENT));
                Gfx.rect(g, x + 1, ry, 2, rowH, Gfx.argb(alpha, ACCENT));
            } else if (hover) {
                Gfx.rect(g, x + 1, ry, listW - 2, rowH, Gfx.argb(alpha * 0.12f, ACCENT));
            }
            String keyTxt = "[" + KeybindManager.keyName(b.key) + "]";
            Gfx.text(g, keyTxt, x + 6, ry + 4, Gfx.argb(alpha, 0xFFFFFF));
            String desc = Gfx.tr().trimToWidth(b.action.label + ": " + paramLabelShort(b), listW - 16 - Gfx.tw(keyTxt) - 14);
            Gfx.text(g, desc, x + 10 + Gfx.tw(keyTxt), ry + 4, Gfx.argb(alpha * 0.75f, 0xCFCBE6));
            if (KeybindManager.conflict(b) != null) Gfx.text(g, "!", x + listW - 10, ry + 4, Gfx.argb(alpha, 0xFF3355));
            addRegion(x, ry, listW, rowH, K_BIND, null, null, idx, true);
        }

        BindEntry b = selBind();
        int ex = x + listW + 10;
        if (b == null) {
            Gfx.text(g, "Выбери бинд слева или добавь новый.", ex, cy + 6, Gfx.argb(alpha * 0.6f, 0xFFFFFF));
            return;
        }
        int a = Gfx.argb(alpha * 0.7f, 0xCFCBE6);
        Gfx.text(g, "Клавиша", ex, cy + 2, a);
        Gfx.text(g, "Действие", ex, cy + 28, a);
        Gfx.text(g, "Режим", ex, cy + 54, a);
        Gfx.text(g, isText(b) ? "Текст (несколько команд через ;)" : "Параметр", ex, cy + 80, a);

        String conflict = KeybindManager.conflict(b);
        if (conflict != null) {
            Gfx.text(g, Gfx.tr().trimToWidth("! Клавиша " + conflict, cw - listW - 10), ex, cy + 112, Gfx.argb(alpha, 0xFF3355));
        }
        Gfx.text(g, b.mode.hint, ex, cy + 126, Gfx.argb(alpha * 0.55f, 0xFFFFFF));
        Gfx.text(g, "Бинды не работают при открытом чате.", ex, cy + 138, Gfx.argb(alpha * 0.4f, 0xFFFFFF));
    }

    private String paramLabelShort(BindEntry e) {
        return switch (e.action) {
            case TOGGLE_FEATURE -> { ModuleDef d = Defs.get(e.param); yield d == null ? e.param : d.name; }
            case OPEN_TAB -> { String t; try { t = Tab.valueOf(e.param).title; } catch (Exception ex) { t = e.param; } yield t; }
            case HOTBAR_SLOT -> "слот " + e.param;
            default -> e.param;
        };
    }
}
