package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import dev.pulse.visuals.util.Sfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;

import java.util.ArrayList;
import java.util.List;

/** Warns when a piece of armor drops to 60% / 40% / 10% durability. */
public class ArmorMonitorModule implements PulseModule {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] NAMES = {"Helmet", "Chestplate", "Leggings", "Boots"};
    private record Alert(String text, int level, long time) {}

    private final int[] level = new int[4];
    private boolean primed;
    private final List<Alert> alerts = new ArrayList<>();

    @Override
    public void tick(MinecraftClient c) {
        var p = c.player;
        if (p == null) { primed = false; return; }
        for (int i = 0; i < 4; i++) {
            ItemStack s = p.getEquippedStack(SLOTS[i]);
            int lv = 0;
            float pct = 100f;
            if (!s.isEmpty() && s.isDamageable()) {
                int max = s.getMaxDamage();
                pct = 100f * (max - s.getDamage()) / max;
                lv = pct <= 10 ? 3 : pct <= 40 ? 2 : pct <= 60 ? 1 : 0;
            }
            if (primed && lv > level[i] && Pulse.on("armor_monitor")) {
                alerts.add(new Alert(NAMES[i] + " " + Math.round(pct) + "%", lv, System.currentTimeMillis()));
                Sfx.play(SoundEvents.BLOCK_ANVIL_LAND, 0.5f + 0.2f * lv, 0.6f);
            }
            level[i] = lv;
        }
        primed = true;
    }

    @Override
    public void hud(DrawContext g, float delta) {
        if (alerts.isEmpty()) return;
        long now = System.currentTimeMillis();
        float life = Pulse.v("armor_monitor", "life");
        float size = Pulse.v("armor_monitor", "size");
        int mid = Pulse.color("armor_monitor");
        int w = g.getScaledWindowWidth();
        int i = 0;
        for (Alert a : new ArrayList<>(alerts)) {
            float age = (now - a.time()) / 1000f;
            if (age > life) { alerts.remove(a); continue; }
            float al = Math.min(Anim.clamp(age / 0.15f), Anim.clamp((life - age) / 0.5f));
            int col = a.level() == 1 ? 0xFFD54A : a.level() == 2 ? mid : 0xFF3355;
            String s = "ARMOR LOW  " + a.text();
            float x = (w - Gfx.tw(s) * size) / 2f;
            float y = 36f + i * 12f * size + (1f - Anim.ease(age / 0.15f)) * -8f;
            Gfx.stext(g, s, x, y, size, Gfx.argb(al, col));
            i++;
        }
    }

    @Override
    public void reset() { alerts.clear(); primed = false; }
}
