package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Shared combat state fed by the attack callback: combo, last hit time, crit flag. */
public final class CombatEvents {
    public static int combo;
    public static int bestCombo;
    public static long lastHitMs;
    public static boolean lastCrit;

    private static boolean prevAttackKey;
    private static int prevHurt;

    public static void onAttack(PlayerEntity p, Entity e) {
        if (!(e instanceof LivingEntity)) return;
        // Same idea as vanilla crit: falling, not on ground / ladder / water, not riding, fully charged, not sprinting.
        lastCrit = p.getVelocity().y < 0 && !p.isOnGround() && !p.isClimbing() && !p.isTouchingWater()
                && !p.hasVehicle() && p.getAttackCooldownProgress(0.5f) > 0.9f && !p.isSprinting();
        combo++;
        bestCombo = Math.max(bestCombo, combo);
        lastHitMs = System.currentTimeMillis();
        TargetTracker.set(e);
        if (Pulse.on("hit_particles")) HitParticlesModule.spawn(e);
        TrainingModule.onHit();
    }

    public static void tick(MinecraftClient c) {
        if (c.player == null) return;
        // a hit on us breaks the combo
        if (c.player.hurtTime > prevHurt) combo = 0;
        prevHurt = c.player.hurtTime;
        // time-out of the combo
        if (combo > 0 && System.currentTimeMillis() - lastHitMs > Pulse.v("hit_counter", "life") * 1000f) combo = 0;
        // swing counter (for training accuracy): rising edge of the attack key
        boolean atk = c.options.attackKey.isPressed();
        if (atk && !prevAttackKey && c.currentScreen == null) TrainingModule.onSwing();
        prevAttackKey = atk;
    }

    public static void reset() { combo = 0; prevHurt = 0; }

    private CombatEvents() {}
}
