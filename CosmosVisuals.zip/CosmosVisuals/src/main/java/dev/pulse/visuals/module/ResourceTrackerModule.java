package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Golden apples, arrows, pearls and totems currently in the inventory. */
public class ResourceTrackerModule implements PulseModule {
    private final int[] counts = new int[4];
    private ItemStack[] icons;

    @Override
    public void tick(MinecraftClient c) {
        if (c.player == null) return;
        int[] n = new int[4];
        PlayerInventory inv = c.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            if (s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE)) n[0] += s.getCount();
            else if (s.isOf(Items.ARROW) || s.isOf(Items.TIPPED_ARROW) || s.isOf(Items.SPECTRAL_ARROW)) n[1] += s.getCount();
            else if (s.isOf(Items.ENDER_PEARL)) n[2] += s.getCount();
            else if (s.isOf(Items.TOTEM_OF_UNDYING)) n[3] += s.getCount();
        }
        System.arraycopy(n, 0, counts, 0, 4);
    }

    @Override
    public void hud(DrawContext g, float delta) {
        if (!Pulse.on("resource_tracker")) return;
        if (icons == null) icons = new ItemStack[]{new ItemStack(Items.GOLDEN_APPLE), new ItemStack(Items.ARROW),
                new ItemStack(Items.ENDER_PEARL), new ItemStack(Items.TOTEM_OF_UNDYING)};
        float size = Pulse.v("resource_tracker", "size");
        float op = Pulse.v("resource_tracker", "opacity");
        int w = 44, h = 4 * 18 + 4;
        float x = (g.getScaledWindowWidth() - w * size) * Pulse.v("resource_tracker", "x") / 100f;
        float y = (g.getScaledWindowHeight() - h * size) * Pulse.v("resource_tracker", "y") / 100f;
        var m = g.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(size, size);
        Gfx.panel(g, 0, 0, w, h, op, 0x9B6BFF);
        for (int i = 0; i < 4; i++) {
            g.drawItem(icons[i], 5, 3 + i * 18);
            int col = counts[i] == 0 ? 0xFF6B86 : 0xFFFFFF;
            Gfx.text(g, String.valueOf(counts[i]), 25, 7 + i * 18, Gfx.argb(op, col));
        }
        m.popMatrix();
    }
}
