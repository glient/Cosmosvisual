package dev.pulse.visuals.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** 2D drawing helpers: neon panels, glow, scaled text. */
public final class Gfx {
    public static int argb(float a, int rgb) {
        int al = (int) (Math.max(0f, Math.min(1f, a)) * 255f + 0.5f);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        t = Anim.clamp(t);
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return (r << 16) | (g << 8) | b;
    }

    public static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }
    public static int tw(String s) { return tr().getWidth(s); }

    public static void rect(DrawContext g, float x, float y, float w, float h, int argb) {
        g.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), argb);
    }

    public static void border(DrawContext g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + 1, argb);
        g.fill(x, y + h - 1, x + w, y + h, argb);
        g.fill(x, y + 1, x + 1, y + h - 1, argb);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, argb);
    }

    /** Soft neon glow around a rectangle. */
    public static void glow(DrawContext g, int x, int y, int w, int h, int rgb, float a) {
        for (int i = 1; i <= 4; i++) border(g, x - i, y - i, w + 2 * i, h + 2 * i, argb(a * 0.22f / i, rgb));
    }

    public static void text(DrawContext g, String s, int x, int y, int argb) {
        if ((argb >>> 24) < 6) return; // alpha below ~2% would render fully opaque in vanilla
        g.drawText(tr(), s, x, y, argb, true);
    }

    public static void ctext(DrawContext g, String s, int cx, int y, int argb) {
        text(g, s, cx - tw(s) / 2, y, argb);
    }

    /** Text drawn with a scale around its own top-left corner. */
    public static void stext(DrawContext g, String s, float x, float y, float scale, int argb) {
        var m = g.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(scale, scale);
        text(g, s, 0, 0, argb);
        m.popMatrix();
    }

    /** Dark translucent panel with a thin neon border and an accent bar on the left. */
    public static void panel(DrawContext g, int x, int y, int w, int h, float a, int accent) {
        rect(g, x, y, w, h, argb(a * 0.78f, 0x0B0B14));
        border(g, x, y, w, h, argb(a * 0.45f, accent));
        rect(g, x, y, 2, h, argb(a, accent));
    }

    private Gfx() {}
}
