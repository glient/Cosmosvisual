package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Effects of the current target, hung under the Target HUD. */
public class PotionTimerModule implements PulseModule {
    private float a;

    @Override
    public void hud(DrawContext g, float delta) {
        LivingEntity t = TargetTracker.target;
        boolean show = Pulse.on("potion_timer") && TargetTracker.active() && t != null && !t.getStatusEffects().isEmpty();
        a = Anim.step(a, show ? 1f : 0f, Pulse.dt * 5f);
        if (!show || a <= 0.02f) return;

        List<StatusEffectInstance> list = new ArrayList<>(t.getStatusEffects());
        list.sort(Comparator.comparingInt(StatusEffectInstance::getDuration).reversed());
        if (list.size() > 8) list = list.subList(0, 8);

        float size = Pulse.v("potion_timer", "size");
        float op = Pulse.v("potion_timer", "opacity") * Anim.ease(a);
        float[] b = TargetHudModule.box(g);

        int rows = list.size();
        int h = 6 + rows * 11;
        var m = g.getMatrices();
        m.pushMatrix();
        m.translate(b[0], b[1] + b[3] + 4);
        m.scale(size, size);
        Gfx.panel(g, 0, 0, TargetHudModule.W, h, op, 0xB46BFF);
        int y = 4;
        for (StatusEffectInstance e : list) {
            boolean good = e.getEffectType().value().isBeneficial();
            int col = good ? 0x7DFFB0 : 0xFF6B86;
            String name = e.getEffectType().value().getName().getString() + (e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : "");
            String time;
            if (e.isInfinite()) time = "inf";
            else {
                int s = e.getDuration() / 20;
                time = String.format("%d:%02d", s / 60, s % 60);
            }
            Gfx.text(g, name, 7, y, Gfx.argb(op, col));
            Gfx.text(g, time, TargetHudModule.W - 6 - Gfx.tw(time), y, Gfx.argb(op, 0xFFFFFF));
            y += 11;
        }
        m.popMatrix();
    }
}
