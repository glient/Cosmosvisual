package dev.pulse.visuals;

import dev.pulse.visuals.config.PulseConfig;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Tiny global helper so modules stay short. */
public final class Pulse {
    public static final String ID = "pulsevisuals";
    public static final Logger LOGGER = LoggerFactory.getLogger("CosmosVisuals");
    public static PulseConfig cfg;

    /** Seconds since the previous HUD frame (used for smooth animations). */
    public static float dt = 0.016f;
    private static long lastNs = System.nanoTime();

    public static void frame() {
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - lastNs) / 1_000_000_000f);
        lastNs = n;
    }

    public static MinecraftClient mc() { return MinecraftClient.getInstance(); }
    public static boolean on(String id) { return cfg.state(id).enabled; }
    public static float v(String id, String key) { return cfg.val(id, key); }
    public static int color(String id) { return cfg.state(id).color & 0xFFFFFF; }
    public static boolean singleplayer() { return mc().isInSingleplayer(); }

    private Pulse() {}
}
