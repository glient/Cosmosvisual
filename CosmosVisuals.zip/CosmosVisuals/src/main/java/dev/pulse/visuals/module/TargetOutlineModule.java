package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.WorldDraw;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.entity.LivingEntity;

/** Box around the target, drawn only while we have line of sight (canSee does a raycast to the eyes). */
public class TargetOutlineModule implements PulseModule {
    @Override
    public void world(WorldRenderContext ctx, float delta) {
        if (!Pulse.on("target_outline") || !TargetTracker.active()) return;
        LivingEntity t = TargetTracker.target;
        var p = Pulse.mc().player;
        if (t == null || p == null || !p.canSee(t)) return;
        WorldDraw.thickBox(ctx, Boxes.lerp(t, delta).expand(0.02), Pulse.color("target_outline"),
                Pulse.v("target_outline", "opacity"), (int) Pulse.v("target_outline", "thickness"));
    }
}
