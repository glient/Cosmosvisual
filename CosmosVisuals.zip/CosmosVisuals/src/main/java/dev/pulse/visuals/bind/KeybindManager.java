package dev.pulse.visuals.bind;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.PulseVisualsClient;
import dev.pulse.visuals.config.Defs;
import dev.pulse.visuals.config.ModuleDef;
import dev.pulse.visuals.config.ModuleState;
import dev.pulse.visuals.gui.PulseScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Polls the user binds every client tick (GLFW key state), only while no screen is open,
 * so chat, the menu and any text field never trigger a bind.
 * Commands go through the normal chat pipeline, exactly as if typed by hand; the server decides if you may run them.
 */
public final class KeybindManager {
    private static final Map<BindEntry, Boolean> RAW = new IdentityHashMap<>();
    private static final Map<BindEntry, Object> HOLD = new IdentityHashMap<>();

    public static void tick(MinecraftClient c) {
        if (c.player == null || c.getWindow() == null) { HOLD.clear(); return; }
        boolean free = c.currentScreen == null;
        long handle = c.getWindow().getHandle();
        for (BindEntry b : new ArrayList<>(Pulse.cfg.binds)) {
            if (b.key < 0) continue;
            boolean raw = GLFW.glfwGetKey(handle, b.key) == GLFW.GLFW_PRESS;
            boolean was = RAW.getOrDefault(b, false);
            if (free && raw && !was) press(c, b);                       // rising edge, never while a screen is open
            if (HOLD.containsKey(b) && (!raw || !free)) release(c, b);
            RAW.put(b, raw);                                             // updated even with a screen open: no fake press afterwards
        }
    }

    private static void press(MinecraftClient c, BindEntry b) {
        boolean hold = b.mode == BindMode.HOLD;
        switch (b.action) {
            case TOGGLE_FEATURE -> {
                ModuleDef d = Defs.get(b.param);
                if (d == null || (d.tab == ModuleDef.Tab.TRAINING && !Pulse.singleplayer())) return;
                ModuleState st = Pulse.cfg.state(d.id);
                if (hold) { HOLD.put(b, st.enabled); st.enabled = true; }
                else st.enabled = !st.enabled;
                Pulse.cfg.markDirty();
            }
            case HOTBAR_SLOT -> {
                int slot = clampSlot(b.param);
                if (hold) HOLD.put(b, c.player.getInventory().getSelectedSlot());
                c.player.getInventory().setSelectedSlot(slot);
            }
            case COMMAND -> send(c, b.param, true);
            case CHAT_MESSAGE -> send(c, b.param, false);
            case OPEN_TAB -> {
                try { c.setScreen(new PulseScreen(ModuleDef.Tab.valueOf(b.param))); } catch (IllegalArgumentException ignored) {}
            }
        }
    }

    private static void release(MinecraftClient c, BindEntry b) {
        Object prev = HOLD.remove(b);
        if (prev == null || c.player == null) return;
        if (b.action == BindAction.TOGGLE_FEATURE && prev instanceof Boolean was) {
            ModuleDef d = Defs.get(b.param);
            if (d != null) { Pulse.cfg.state(d.id).enabled = was; Pulse.cfg.markDirty(); }
        } else if (b.action == BindAction.HOTBAR_SLOT && prev instanceof Integer slot) {
            c.player.getInventory().setSelectedSlot(slot);
        }
    }

    private static int clampSlot(String s) {
        try { return Math.max(1, Math.min(9, Integer.parseInt(s.trim()))) - 1; } catch (Exception e) { return 0; }
    }

    /** Several commands can be chained with ';'. A message starting with '/' is sent as a command. */
    private static void send(MinecraftClient c, String text, boolean command) {
        if (text == null || c.player == null) return;
        ClientPlayNetworkHandler nh = c.player.networkHandler;
        if (command) {
            for (String part : text.split(";")) {
                String s = part.trim();
                if (s.startsWith("/")) s = s.substring(1);
                if (!s.isEmpty()) nh.sendChatCommand(s);
            }
        } else {
            String s = text.trim();
            if (s.isEmpty()) return;
            if (s.startsWith("/")) nh.sendChatCommand(s.substring(1));
            else nh.sendChatMessage(s);
        }
    }

    public static String keyName(int code) {
        if (code < 0) return "—";
        return InputUtil.Type.KEYSYM.createFromCode(code).getLocalizedText().getString();
    }

    /** Returns a human readable reason if the key is already used elsewhere, else null. */
    public static String conflict(BindEntry self) {
        if (self.key < 0) return null;
        int i = 0;
        for (BindEntry o : Pulse.cfg.binds) {
            i++;
            if (o != self && o.key == self.key) return "уже занята биндом №" + i;
        }
        String tk = InputUtil.Type.KEYSYM.createFromCode(self.key).getTranslationKey();
        for (KeyBinding kb : MinecraftClient.getInstance().options.allKeys) {
            if (kb.getBoundKeyTranslationKey().equals(tk)) {
                return kb == PulseVisualsClient.MENU_KEY ? "это клавиша меню Cosmos" : "занята в настройках управления Minecraft";
            }
        }
        return null;
    }

    private KeybindManager() {}
}
