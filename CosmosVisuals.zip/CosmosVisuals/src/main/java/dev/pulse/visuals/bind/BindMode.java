package dev.pulse.visuals.bind;

public enum BindMode {
    PRESS("Press", "Press: один раз при нажатии"),
    HOLD("Hold", "Hold: пока удерживаешь клавишу"),
    TOGGLE("Toggle", "Toggle: переключение (для функций мода)");

    public final String label;
    public final String hint;
    BindMode(String label, String hint) { this.label = label; this.hint = hint; }

    public BindMode next() { return values()[(ordinal() + 1) % values().length]; }
}
