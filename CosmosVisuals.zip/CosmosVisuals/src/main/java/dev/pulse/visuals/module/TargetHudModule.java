package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

import java.util.Locale;

public class TargetHudModule implements PulseModule {
    public static final int W = 124, H = 46;
    private float a;
    private String name = "";
    private float hp, max = 20, abs;
    private int armor;
    private float dist;

    /** Screen rectangle of the panel (also used to hang the potion timer under it). */
    static float[] box(DrawContext g) {
        float size = Pulse.v("target_hud", "size");
        float sw = W * size, sh = H * size;
        float x = (g.getScaledWindowWidth() - sw) * Pulse.v("target_hud", "x") / 100f;
        float y = (g.getScaledWindowHeight() - sh) * Pulse.v("target_hud", "y") / 100f;
        return new float[]{x, y, sw, sh};
    }

    @Override
    public void hud(DrawContext g, float delta) {
        boolean show = Pulse.on("target_hud") && TargetTracker.active();
        a = Anim.step(a, show ? 1f : 0f, Pulse.dt * 5f);
        LivingEntity t = TargetTracker.target;
        if (show && t != null) {
            name = t.getName().getString();
            hp = t.getHealth();
            max = Math.max(1f, t.getMaxHealth());
            abs = t.getAbsorptionAmount();
            armor = t.getArmor();
            dist = Pulse.mc().player.distanceTo(t);
        }
        if (a <= 0.02f) return;

        float size = Pulse.v("target_hud", "size");
        float op = Pulse.v("target_hud", "opacity") * Anim.ease(a);
        int accent = Pulse.color("target_hud");
        float[] b = box(g);

        var m = g.getMatrices();
        m.pushMatrix();
        m.translate(b[0] + (1f - Anim.ease(a)) * 10f, b[1]);
        m.scale(size, size);

        Gfx.panel(g, 0, 0, W, H, op, accent);
        Gfx.text(g, name, 8, 5, Gfx.argb(op, 0xFFFFFF));

        float frac = Anim.clamp(hp / max);
        Gfx.rect(g, 8, 17, W - 16, 6, Gfx.argb(op * 0.6f, 0x1A1A28));
        int hpCol = Gfx.mix(0xFF3355, 0x3CFF8A, frac);
        Gfx.rect(g, 8, 17, (W - 16) * frac, 6, Gfx.argb(op, hpCol));
        if (abs > 0) Gfx.rect(g, 8, 17, Math.min(W - 16, (W - 16) * abs / max), 2, Gfx.argb(op, 0xFFD54A));

        String hpText = String.format(Locale.ROOT, "HP %.1f / %.1f", hp, max) + (abs > 0 ? String.format(Locale.ROOT, " +%.1f", abs) : "");
        Gfx.text(g, hpText, 8, 26, Gfx.argb(op, hpCol));
        Gfx.text(g, "Armor " + armor, 8, 36, Gfx.argb(op, 0x9FB4FF));
        String ds = String.format(Locale.ROOT, "%.1fm", dist);
        Gfx.text(g, ds, W - 8 - Gfx.tw(ds), 36, Gfx.argb(op, accent));
        m.popMatrix();
    }
}
