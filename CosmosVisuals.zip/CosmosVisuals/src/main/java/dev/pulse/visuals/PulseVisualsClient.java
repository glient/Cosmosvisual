package dev.pulse.visuals;

import dev.pulse.visuals.bind.KeybindManager;
import dev.pulse.visuals.config.ModuleDef;
import dev.pulse.visuals.config.PulseConfig;
import dev.pulse.visuals.gui.PulseScreen;
import dev.pulse.visuals.module.CombatEvents;
import dev.pulse.visuals.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class PulseVisualsClient implements ClientModInitializer {
    public static KeyBinding MENU_KEY;
    public static KeyBinding ZOOM_KEY;
    private static int saveTimer;

    @Override
    public void onInitializeClient() {
        Pulse.cfg = PulseConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(Pulse.ID, "keys"));
        MENU_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.pulsevisuals.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        ZOOM_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.pulsevisuals.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, category));

        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(PulseVisualsClient::tick);
        HudRenderCallback.EVENT.register((graphics, tickCounter) -> ModuleManager.hud(graphics, tickCounter.getTickProgress(false)));
        WorldRenderEvents.AFTER_ENTITIES.register(ModuleManager::world);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient()) CombatEvents.onAttack(player, entity);
            return ActionResult.PASS;
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ModuleManager.reset());
        Pulse.LOGGER.info("Cosmos Visuals loaded. Menu: Right Shift");
    }

    private static void tick(MinecraftClient c) {
        while (MENU_KEY.wasPressed()) {
            if (c.currentScreen == null && c.player != null) c.setScreen(new PulseScreen(PulseScreen.lastTab));
        }
        KeybindManager.tick(c);
        ModuleManager.tick(c);
        if (++saveTimer >= 100) { saveTimer = 0; Pulse.cfg.saveIfDirty(); }
    }

    @SuppressWarnings("unused")
    private static void keepImports(ModuleDef d) {}
}
