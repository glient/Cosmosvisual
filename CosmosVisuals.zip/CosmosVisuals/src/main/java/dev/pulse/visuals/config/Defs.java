package dev.pulse.visuals.config;

import dev.pulse.visuals.config.ModuleDef.Tab;

import java.util.ArrayList;
import java.util.List;

/** Every module with its default settings. Add a line here + a module class to extend the mod. */
public final class Defs {
    public static final List<ModuleDef> ALL = new ArrayList<>();

    private static ModuleDef add(ModuleDef d) { ALL.add(d); return d; }

    static {
        // ---------------- TARGET ----------------
        add(ModuleDef.of("target_hud", "Target HUD", Tab.TARGET).color(0x00E5FF)
                .i("x", "Position X %", 0, 100, 72).i("y", "Position Y %", 0, 100, 45)
                .f("size", "Size", 0.6f, 2f, 1f).f("opacity", "Opacity", 0.1f, 1f, 0.9f)
                .f("life", "Lifetime (s)", 1f, 10f, 4f));
        add(ModuleDef.of("potion_timer", "Potion Timer", Tab.TARGET)
                .f("size", "Size", 0.6f, 2f, 1f).f("opacity", "Opacity", 0.1f, 1f, 0.9f));
        add(ModuleDef.of("totem_alert", "Totem Alert", Tab.TARGET).color(0xFFD54A)
                .f("size", "Size", 0.6f, 3f, 1.4f).f("opacity", "Opacity", 0.1f, 1f, 1f)
                .f("life", "Lifetime (s)", 0.5f, 5f, 2f).f("volume", "Volume", 0f, 1f, 0.8f));
        add(ModuleDef.of("target_outline", "Target Outline", Tab.TARGET).color(0xFF4D6D)
                .f("opacity", "Opacity", 0.2f, 1f, 0.9f).i("thickness", "Thickness", 1, 4, 2));

        // ---------------- SELF ----------------
        add(ModuleDef.of("armor_monitor", "Armor Monitor", Tab.SELF).color(0xFFB020)
                .f("size", "Size", 0.6f, 2f, 1f).f("life", "Lifetime (s)", 1f, 10f, 4f));
        add(ModuleDef.of("resource_tracker", "Resource Tracker", Tab.SELF)
                .i("x", "Position X %", 0, 100, 1).i("y", "Position Y %", 0, 100, 40)
                .f("size", "Size", 0.6f, 2f, 1f).f("opacity", "Opacity", 0.1f, 1f, 0.85f));
        add(ModuleDef.of("low_hp", "Low HP Pulse", Tab.SELF).color(0xFF2D4A)
                .f("opacity", "Opacity", 0.2f, 1f, 0.8f).i("threshold", "Critical HP", 2, 10, 6));
        add(ModuleDef.of("attack_direction", "Attack Direction", Tab.SELF).color(0xFF5577)
                .f("size", "Size", 0.6f, 2f, 1f).f("opacity", "Opacity", 0.1f, 1f, 1f)
                .f("life", "Lifetime (s)", 0.3f, 3f, 1.2f));

        // ---------------- COMBAT ----------------
        add(ModuleDef.of("attack_cooldown", "Attack Cooldown", Tab.COMBAT)
                .f("size", "Size", 0.6f, 2f, 1f).f("opacity", "Opacity", 0.1f, 1f, 0.9f));
        add(ModuleDef.of("crosshair_feedback", "Crosshair Feedback", Tab.COMBAT).color(0xFF3355)
                .f("size", "Size", 0.5f, 3f, 1f).f("opacity", "Opacity", 0.1f, 1f, 1f));
        add(ModuleDef.of("damage_numbers", "Damage Numbers", Tab.COMBAT)
                .f("size", "Size", 0.6f, 3f, 1f).f("opacity", "Opacity", 0.1f, 1f, 1f)
                .f("life", "Lifetime (s)", 0.5f, 3f, 1.2f));
        add(ModuleDef.of("hit_particles", "Hit Particles", Tab.COMBAT)
                .i("count", "Amount", 1, 30, 10));
        add(ModuleDef.of("hit_counter", "Hit Counter", Tab.COMBAT).color(0xFFD54A)
                .i("x", "Position X %", 0, 100, 50).i("y", "Position Y %", 0, 100, 62)
                .f("size", "Size", 0.6f, 3f, 1f).f("life", "Reset time (s)", 1f, 10f, 3f));
        add(ModuleDef.of("trajectory", "Trajectory Prediction", Tab.COMBAT).color(0x7DF9FF)
                .f("opacity", "Opacity", 0.1f, 1f, 0.9f));

        // ---------------- MISC ----------------
        add(ModuleDef.of("hitboxes", "Custom Hitboxes", Tab.MISC).color(0x9B6BFF).off()
                .i("thickness", "Thickness", 1, 4, 1).f("opacity", "Opacity", 0.2f, 1f, 1f));
        add(ModuleDef.of("fullbright", "Fullbright", Tab.MISC).off());
        add(ModuleDef.of("zoom", "Zoom (hold C)", Tab.MISC)
                .f("factor", "Zoom factor", 1.5f, 10f, 4f));
        add(ModuleDef.of("toggle_sprint", "Toggle Sprint", Tab.MISC).off());
        add(ModuleDef.of("stretch", "Screen Stretch", Tab.MISC).off()
                .f("factor", "Stretch", 1f, 2f, 1.25f));

        // ---------------- TRAINING (singleplayer only) ----------------
        add(ModuleDef.of("training_nodamage", "No damage to self", Tab.TRAINING).off());
        add(ModuleDef.of("training_infinite", "Infinite items", Tab.TRAINING).off());
        add(ModuleDef.of("training_stats", "Hit stats HUD", Tab.TRAINING).color(0x3CFF8A)
                .i("x", "Position X %", 0, 100, 1).i("y", "Position Y %", 0, 100, 70)
                .f("size", "Size", 0.6f, 2f, 1f));
    }

    public static ModuleDef get(String id) {
        for (ModuleDef d : ALL) if (d.id.equals(id)) return d;
        return null;
    }

    public static List<ModuleDef> forTab(Tab tab) {
        List<ModuleDef> out = new ArrayList<>();
        for (ModuleDef d : ALL) if (d.tab == tab) out.add(d);
        return out;
    }

    private Defs() {}
}
