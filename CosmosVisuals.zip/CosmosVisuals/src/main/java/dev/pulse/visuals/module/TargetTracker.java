package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

/** Who is "the target": whatever we look at or hit last. Shared by HUD, potion timer, outline, damage numbers. */
public final class TargetTracker {
    public static LivingEntity target;
    private static long lastSeen;

    public static void set(Entity e) {
        MinecraftClient c = Pulse.mc();
        if (e instanceof LivingEntity le && c.player != null && e != c.player) {
            target = le;
            lastSeen = System.currentTimeMillis();
        }
    }

    public static void tick(MinecraftClient c) {
        if (c.player == null || c.world == null) { target = null; return; }
        Entity looked = c.targetedEntity; // precise hitbox raycast done by vanilla
        if (looked != null) set(looked);
    }

    public static boolean active() {
        if (target == null || target.isRemoved()) return false;
        return System.currentTimeMillis() - lastSeen < Pulse.v("target_hud", "life") * 1000f;
    }

    public static void reset() { target = null; }

    private TargetTracker() {}
}
