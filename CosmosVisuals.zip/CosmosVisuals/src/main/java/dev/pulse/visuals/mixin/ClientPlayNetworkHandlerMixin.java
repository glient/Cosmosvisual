package dev.pulse.visuals.mixin;

import dev.pulse.visuals.module.TotemAlertModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Totem Alert: the server announces a totem activation with entity status 35.
 * Fabric has no event for this packet, so we listen at the end of the vanilla handler (vanilla behaviour is untouched).
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityStatus", at = @At("TAIL"))
    private void pulsevisuals$onEntityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
        if (packet.getStatus() != 35) return;
        ClientWorld world = MinecraftClient.getInstance().world;
        if (world == null) return;
        Entity e = packet.getEntity(world);
        if (e != null) TotemAlertModule.onPop(e);
    }
}
