package dev.pulse.visuals.util;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * World-space box outlines. Vertex data in WorldRenderEvents is camera-relative, so every box is shifted by -camera.
 * If a Yarn rename breaks the build, the only places to touch are cam(), RenderLayer.getLines() and VertexRendering.drawBox().
 */
public final class WorldDraw {
    public static Vec3d cam(WorldRenderContext ctx) {
        return ctx.camera().getCameraPos(); // older Yarn: getPos()
    }

    public static void box(WorldRenderContext ctx, Box b, int rgb, float a) {
        VertexConsumerProvider cons = ctx.consumers();
        if (cons == null) return;
        MatrixStack ms = ctx.matrices();
        if (ms == null) ms = new MatrixStack();
        Vec3d c = cam(ctx);
        VertexConsumer vc = cons.getBuffer(RenderLayer.getLines());
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, bl = (rgb & 255) / 255f;
        VertexRendering.drawBox(ms, vc, b.offset(-c.x, -c.y, -c.z), r, g, bl, a);
    }

    /** Outline made of several nested boxes, which is how the "thickness" slider is faked. */
    public static void thickBox(WorldRenderContext ctx, Box b, int rgb, float a, int layers) {
        for (int i = 0; i < layers; i++) box(ctx, b.expand(i * 0.008), rgb, a);
    }

    private WorldDraw() {}
}
