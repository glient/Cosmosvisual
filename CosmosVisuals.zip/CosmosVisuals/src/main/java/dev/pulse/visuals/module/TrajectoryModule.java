package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.WorldDraw;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Shows where a charged bow / loaded crossbow arrow or a thrown ender pearl will land.
 * It only simulates physics along your current look direction. It never rotates the camera and never targets anyone.
 */
public class TrajectoryModule implements PulseModule {
    @Override
    public void world(WorldRenderContext ctx, float delta) {
        if (!Pulse.on("trajectory")) return;
        var mc = Pulse.mc();
        var p = mc.player;
        var world = mc.world;
        if (p == null || world == null || mc.currentScreen != null) return;

        double speed = 0, gravity = 0;
        for (ItemStack st : new ItemStack[]{p.getMainHandStack(), p.getOffHandStack()}) {
            if (st.isOf(Items.ENDER_PEARL)) { speed = 1.5; gravity = 0.03; break; }
            if (st.isOf(Items.BOW) && p.isUsingItem() && p.getActiveItem().isOf(Items.BOW)) {
                float pull = BowItem.getPullProgress(p.getItemUseTime());
                if (pull >= 0.1f) { speed = pull * 3.0; gravity = 0.05; break; }
            }
            if (st.isOf(Items.CROSSBOW) && CrossbowItem.isCharged(st)) { speed = 3.15; gravity = 0.05; break; }
        }
        if (speed <= 0) return;

        Vec3d pos = p.getCameraPosVec(delta).subtract(0, 0.1, 0);
        Vec3d vel = p.getRotationVec(delta).multiply(speed);
        List<Vec3d> pts = new ArrayList<>();
        Vec3d hit = null;

        outer:
        for (int tick = 0; tick < 120; tick++) {
            for (int sub = 0; sub < 4; sub++) {              // 4 sub-steps per tick so thin walls are not skipped
                Vec3d next = pos.add(vel.multiply(0.25));
                BlockHitResult r = world.raycast(new RaycastContext(pos, next,
                        RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
                if (r.getType() != HitResult.Type.MISS) { hit = r.getPos(); break outer; }
                pos = next;
                pts.add(pos);
            }
            vel = vel.multiply(0.99).add(0, -gravity, 0);
            if (pos.y < world.getBottomY() - 8) break;
        }

        int col = Pulse.color("trajectory");
        float op = Pulse.v("trajectory", "opacity");
        int n = pts.size();
        for (int i = 0; i < n; i += 2) {                     // dotted line, fades towards the end
            Vec3d q = pts.get(i);
            float k = 1f - 0.6f * i / Math.max(1, n);
            WorldDraw.box(ctx, new Box(q.x - 0.025, q.y - 0.025, q.z - 0.025, q.x + 0.025, q.y + 0.025, q.z + 0.025), col, op * k);
        }
        if (hit != null) {
            WorldDraw.box(ctx, new Box(hit.x - 0.12, hit.y - 0.12, hit.z - 0.12, hit.x + 0.12, hit.y + 0.12, hit.z + 0.12), col, op);
        }
    }
}
