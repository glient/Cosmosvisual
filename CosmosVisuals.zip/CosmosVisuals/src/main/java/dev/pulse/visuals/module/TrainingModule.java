package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayDeque;
import java.util.Locale;
import java.util.UUID;

/**
 * Training mode, singleplayer only (MinecraftClient.isInSingleplayer()).
 * Everything that changes the world runs on the integrated server thread. On a multiplayer server the module does nothing
 * and its toggles are switched off again.
 */
public class TrainingModule implements PulseModule {
    private static int hits, swings, bestCombo;
    private static float damage;
    private static final ArrayDeque<float[]> DPS = new ArrayDeque<>(); // {timeMs (as float offset), damage}
    private static final ArrayDeque<Long> DPS_T = new ArrayDeque<>();

    private boolean invulnApplied; // touched only on the server thread

    public static boolean available() { return Pulse.mc().isInSingleplayer(); }

    public static void onHit() {
        if (!available()) return;
        hits++;
        bestCombo = Math.max(bestCombo, CombatEvents.combo);
    }

    public static void onSwing() { if (available()) swings++; }

    public static void onDamage(float d) {
        if (!available()) return;
        if (System.currentTimeMillis() - CombatEvents.lastHitMs > 900) return; // only damage caused by our hits
        damage += d;
        DPS.add(new float[]{d});
        DPS_T.add(System.currentTimeMillis());
    }

    public static void resetStats() {
        hits = swings = bestCombo = 0;
        damage = 0;
        DPS.clear();
        DPS_T.clear();
    }

    // ---- actions used by the Training tab buttons ----
    private static void runAsPlayer(String cmd) {
        MinecraftClient c = Pulse.mc();
        IntegratedServer s = c.getServer();
        if (s == null || c.player == null) return;
        s.execute(() -> s.getCommandManager().parseAndExecute(s.getCommandSource(), "execute as @p at @s run " + cmd));
    }

    /** Immobile mannequin 3 blocks in front of you. */
    public static void spawnDummy() {
        if (!available()) return;
        runAsPlayer("summon minecraft:mannequin ^ ^ ^3 {immovable:true,hide_description:true,Tags:[\"pv_dummy\"]}");
    }

    public static void teleportToDummy() {
        if (!available()) return;
        runAsPlayer("execute at @e[tag=pv_dummy,sort=nearest,limit=1] run tp @s ~ ~ ~3 facing entity @e[tag=pv_dummy,sort=nearest,limit=1] eyes");
    }

    public static void removeDummies() {
        if (!available()) return;
        runAsPlayer("kill @e[tag=pv_dummy]");
    }

    @Override
    public void tick(MinecraftClient c) {
        if (c.player == null) return;
        if (!available()) {
            // on a server: switch everything off
            boolean changed = false;
            for (String id : new String[]{"training_nodamage", "training_infinite"}) {
                if (Pulse.on(id)) { Pulse.cfg.state(id).enabled = false; changed = true; }
            }
            if (changed) Pulse.cfg.markDirty();
            return;
        }
        IntegratedServer s = c.getServer();
        if (s == null) return;
        boolean noDmg = Pulse.on("training_nodamage");
        boolean inf = Pulse.on("training_infinite");
        UUID id = c.player.getUuid();
        s.execute(() -> {
            ServerPlayerEntity sp = s.getPlayerManager().getPlayer(id);
            if (sp == null) return;
            if (noDmg && !invulnApplied) { sp.setInvulnerable(true); invulnApplied = true; }
            else if (!noDmg && invulnApplied) { sp.setInvulnerable(false); invulnApplied = false; }
            if (inf) {
                for (ItemStack st : new ItemStack[]{sp.getMainHandStack(), sp.getOffHandStack()}) {
                    if (st.isEmpty()) continue;
                    if (st.getCount() < st.getMaxCount()) st.setCount(st.getMaxCount());
                    if (st.isDamageable() && st.getDamage() > 0) st.setDamage(0);
                }
            }
        });
    }

    @Override
    public void hud(DrawContext g, float delta) {
        if (!available() || !Pulse.on("training_stats")) return;
        long now = System.currentTimeMillis();
        while (!DPS_T.isEmpty() && now - DPS_T.peekFirst() > 5000) { DPS_T.pollFirst(); DPS.pollFirst(); }
        float sum = 0;
        for (float[] e : DPS) sum += e[0];
        float dps = sum / 5f;
        float acc = swings == 0 ? 0 : Math.min(100f, 100f * hits / swings);

        float size = Pulse.v("training_stats", "size");
        int col = Pulse.color("training_stats");
        int w = 96, h = 54;
        float x = (g.getScaledWindowWidth() - w * size) * Pulse.v("training_stats", "x") / 100f;
        float y = (g.getScaledWindowHeight() - h * size) * Pulse.v("training_stats", "y") / 100f;
        var m = g.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(size, size);
        Gfx.panel(g, 0, 0, w, h, 0.9f, col);
        Gfx.text(g, "TRAINING", 7, 4, Gfx.argb(1f, col));
        Gfx.text(g, "Hits " + hits + " / " + swings, 7, 15, 0xFFFFFFFF);
        Gfx.text(g, String.format(Locale.ROOT, "Accuracy %.0f%%", acc), 7, 25, 0xFFFFFFFF);
        Gfx.text(g, String.format(Locale.ROOT, "DPS %.1f  Dmg %.0f", dps, damage), 7, 35, 0xFFFFFFFF);
        Gfx.text(g, "Best combo " + bestCombo, 7, 45, 0xFFFFFFFF);
        m.popMatrix();
    }
}
