package dev.pulse.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.bind.BindAction;
import dev.pulse.visuals.bind.BindEntry;
import dev.pulse.visuals.bind.BindMode;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** config/pulsevisuals.json: module settings + binds. */
public final class PulseConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public Map<String, ModuleState> modules = new LinkedHashMap<>();
    public List<BindEntry> binds = new ArrayList<>();
    private transient boolean dirty;

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("pulsevisuals.json"); }

    public static PulseConfig load() {
        PulseConfig cfg = null;
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                cfg = GSON.fromJson(r, PulseConfig.class);
            } catch (Exception e) {
                Pulse.LOGGER.error("Could not read pulsevisuals.json, using defaults", e);
            }
        }
        if (cfg == null) cfg = new PulseConfig();
        if (cfg.modules == null) cfg.modules = new LinkedHashMap<>();
        if (cfg.binds == null) cfg.binds = new ArrayList<>();
        cfg.normalize();
        cfg.save();
        return cfg;
    }

    /** Fill in anything missing (new modules / new sliders after an update). */
    private void normalize() {
        for (ModuleDef d : Defs.ALL) {
            ModuleState s = state(d.id);
            if (s.values == null) s.values = new LinkedHashMap<>();
            for (ModuleDef.Slider sl : d.sliders) s.values.putIfAbsent(sl.key(), sl.def());
        }
        binds.removeIf(b -> b == null);
        for (BindEntry b : binds) {
            if (b.action == null) b.action = BindAction.COMMAND;
            if (b.mode == null) b.mode = BindMode.PRESS;
            if (b.param == null) b.param = "";
        }
    }

    public ModuleState state(String id) {
        return modules.computeIfAbsent(id, k -> {
            ModuleState s = new ModuleState();
            ModuleDef d = Defs.get(k);
            if (d != null) {
                s.enabled = d.defEnabled;
                s.color = d.defColor;
            }
            return s;
        });
    }

    public float val(String id, String key) {
        Float f = state(id).values.get(key);
        if (f != null) return f;
        ModuleDef d = Defs.get(id);
        if (d != null) for (ModuleDef.Slider s : d.sliders) if (s.key().equals(key)) return s.def();
        return 0f;
    }

    public void markDirty() { dirty = true; }

    public void saveIfDirty() { if (dirty) save(); }

    public void save() {
        dirty = false;
        try {
            Path p = path();
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(p)) {
                GSON.toJson(this, w);
            }
        } catch (IOException e) {
            Pulse.LOGGER.error("Could not write pulsevisuals.json", e);
        }
    }
}
