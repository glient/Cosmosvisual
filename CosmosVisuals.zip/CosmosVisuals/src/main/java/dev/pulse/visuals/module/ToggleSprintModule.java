package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Tap the sprint key once to stay in sprint mode while walking forward; tap again to stop. */
public class ToggleSprintModule implements PulseModule {
    private boolean toggled, prevKey;
    private float a;

    @Override
    public void tick(MinecraftClient c) {
        boolean key = c.options.sprintKey.isPressed();
        var p = c.player;
        if (!Pulse.on("toggle_sprint") || p == null || c.currentScreen != null) {
            toggled = false;
            prevKey = key;
            return;
        }
        if (key && !prevKey) toggled = !toggled;
        prevKey = key;
        if (toggled && c.options.forwardKey.isPressed() && !p.isSneaking() && !p.isUsingItem()
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }

    @Override
    public void hud(DrawContext g, float delta) {
        a = Anim.step(a, toggled ? 1f : 0f, Pulse.dt * 6f);
        if (a <= 0.02f) return;
        Gfx.text(g, "Sprint [Toggled]", 6, g.getScaledWindowHeight() - 14, Gfx.argb(a, 0x7DF9FF));
    }

    @Override
    public void reset() { toggled = false; }
}
