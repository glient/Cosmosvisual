package dev.pulse.visuals.util;

public final class Anim {
    public static float step(float cur, float target, float amt) {
        return cur < target ? Math.min(target, cur + amt) : Math.max(target, cur - amt);
    }
    public static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    public static float ease(float t) { t = clamp(t); float k = 1f - t; return 1f - k * k * k; }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private Anim() {}
}
