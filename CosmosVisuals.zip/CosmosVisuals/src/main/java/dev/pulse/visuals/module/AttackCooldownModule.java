package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.gui.DrawContext;

/** Small charge bar above the selected hotbar slot: red -> yellow -> green. */
public class AttackCooldownModule implements PulseModule {
    private float shown;

    @Override
    public void hud(DrawContext g, float delta) {
        if (!Pulse.on("attack_cooldown")) return;
        var p = Pulse.mc().player;
        float prog = p.getAttackCooldownProgress(0f);
        shown += (prog - shown) * Math.min(1f, Pulse.dt * 20f);
        int col = prog >= 0.95f ? 0x3CFF8A : prog >= 0.5f ? 0xFFD54A : 0xFF3355;
        float op = Pulse.v("attack_cooldown", "opacity") * (prog >= 0.999f ? 0.45f : 1f);
        float size = Pulse.v("attack_cooldown", "size");
        int slot = p.getInventory().getSelectedSlot();
        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();
        float x = w / 2f - 91 + slot * 20 + 10;   // centre of the selected slot
        float y = h - 22 - 6;
        var m = g.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(size, size);
        Gfx.rect(g, -8, 0, 16, 3, Gfx.argb(op * 0.7f, 0x0B0B14));
        Gfx.rect(g, -8, 0, 16 * shown, 3, Gfx.argb(op, col));
        if (prog >= 0.95f) Gfx.glow(g, -8, 0, 16, 3, col, op * 0.8f);
        m.popMatrix();
    }
}
