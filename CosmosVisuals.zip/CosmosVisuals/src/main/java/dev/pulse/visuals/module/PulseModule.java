package dev.pulse.visuals.module;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** One feature of the mod. Every method is optional. */
public interface PulseModule {
    default void tick(MinecraftClient c) {}
    default void hud(DrawContext g, float delta) {}
    default void world(WorldRenderContext ctx, float delta) {}
    default void reset() {}
}
