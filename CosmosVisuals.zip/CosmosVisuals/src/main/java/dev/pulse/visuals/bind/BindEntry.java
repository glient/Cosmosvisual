package dev.pulse.visuals.bind;

/** One user bind. Serialised to JSON as-is. key = GLFW key code, -1 = not bound. */
public class BindEntry {
    public int key = -1;
    public BindAction action = BindAction.COMMAND;
    public String param = "";
    public BindMode mode = BindMode.PRESS;
}
