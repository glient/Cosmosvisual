package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Floating numbers when the target's health changes: red = damage, gold = critical hit, green = healing.
 * They float up from the crosshair (screen space), which avoids projecting world coordinates.
 */
public class DamageNumbersModule implements PulseModule {
    private static final class Num {
        String text; float ox; long time; int color;
    }
    private final List<Num> nums = new ArrayList<>();
    private final Random rnd = new Random();
    private int lastId = -1;
    private float lastHp;

    @Override
    public void tick(MinecraftClient c) {
        LivingEntity t = TargetTracker.target;
        if (t == null || !TargetTracker.active()) { lastId = -1; return; }
        float hp = t.getHealth() + t.getAbsorptionAmount();
        if (t.getId() != lastId) { lastId = t.getId(); lastHp = hp; return; }
        float d = lastHp - hp;
        lastHp = hp;
        if (Math.abs(d) < 0.05f || !Pulse.on("damage_numbers")) {
            if (d > 0.05f) TrainingModule.onDamage(d);
            return;
        }
        Num n = new Num();
        n.time = System.currentTimeMillis();
        n.ox = (rnd.nextFloat() - 0.5f) * 40f;
        if (d > 0) {
            boolean crit = CombatEvents.lastCrit && n.time - CombatEvents.lastHitMs < 500;
            n.color = crit ? 0xFFD54A : 0xFF3355;
            n.text = String.format(Locale.ROOT, "%.1f", d);
            TrainingModule.onDamage(d);
        } else {
            n.color = 0x3CFF8A;
            n.text = String.format(Locale.ROOT, "+%.1f", -d);
        }
        nums.add(n);
        if (nums.size() > 12) nums.remove(0);
    }

    @Override
    public void hud(DrawContext g, float delta) {
        if (nums.isEmpty()) return;
        long now = System.currentTimeMillis();
        float life = Pulse.v("damage_numbers", "life") * 1000f;
        float size = Pulse.v("damage_numbers", "size");
        float op = Pulse.v("damage_numbers", "opacity");
        float cx = g.getScaledWindowWidth() / 2f, cy = g.getScaledWindowHeight() / 2f;
        for (Num n : new ArrayList<>(nums)) {
            float age = now - n.time;
            if (age > life) { nums.remove(n); continue; }
            float t = age / life;
            float al = (t < 0.7f ? 1f : 1f - (t - 0.7f) / 0.3f) * op;
            float sc = size * (1f + 0.5f * (1f - Anim.clamp(age / 120f)));  // pop-in
            float w = Gfx.tw(n.text) * sc;
            Gfx.stext(g, n.text, cx + 22 + n.ox - w / 2f, cy - 12 - Anim.ease(t) * 34f, sc, Gfx.argb(al, n.color));
        }
    }

    @Override
    public void reset() { nums.clear(); lastId = -1; }
}
