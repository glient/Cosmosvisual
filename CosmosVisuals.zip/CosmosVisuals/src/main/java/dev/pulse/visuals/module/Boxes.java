package dev.pulse.visuals.module;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

final class Boxes {
    /** Bounding box at the interpolated (smooth) position so outlines do not jitter. */
    static Box lerp(Entity e, float delta) {
        Vec3d p = e.getLerpedPos(delta);
        return e.getBoundingBox().offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ());
    }
    private Boxes() {}
}
