package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.gui.DrawContext;

/** Red pulsing edges + a pixel heart when health is critical. */
public class LowHpPulseModule implements PulseModule {
    private static final String[] HEART = {
            "0110110",
            "1111111",
            "1111111",
            "0111110",
            "0011100",
            "0001000"};
    private float a;

    @Override
    public void hud(DrawContext g, float delta) {
        var p = Pulse.mc().player;
        float thr = Pulse.v("low_hp", "threshold");
        boolean show = Pulse.on("low_hp") && p.isAlive() && p.getHealth() <= thr;
        a = Anim.step(a, show ? 1f : 0f, Pulse.dt * 3f);
        if (a <= 0.01f) return;

        float strength = Anim.clamp(1f - p.getHealth() / thr * 0.6f);   // lower hp -> stronger
        float speed = 4f + 6f * strength;                              // lower hp -> faster beat
        float pulse = (float) (Math.sin(System.nanoTime() / 1e9 * speed) * 0.5 + 0.5);
        float op = Pulse.v("low_hp", "opacity") * a;
        int col = Pulse.color("low_hp");
        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();

        // edge glow: nested translucent strips, strongest at the border
        int steps = 22;
        float edge = 26f + 40f * pulse * strength;
        float stripe = edge / steps;
        for (int i = 0; i < steps; i++) {
            float k = 1f - i / (float) steps;
            int c = Gfx.argb(op * (0.14f + 0.22f * pulse) * k * k * 2.2f, col);
            int o0 = Math.round(i * stripe), o1 = Math.round((i + 1) * stripe);
            if (o1 <= o0) continue;
            g.fill(0, o0, w, o1, c);               // top
            g.fill(0, h - o1, w, h - o0, c);       // bottom
            g.fill(o0, 0, o1, h, c);               // left
            g.fill(w - o1, 0, w - o0, h, c);       // right
        }

        // heart above the hotbar
        float scale = 2.2f + 1.2f * pulse;
        int cell = Math.max(1, Math.round(scale));
        int hx = w / 2 - (7 * cell) / 2;
        int hy = h - 74 - (int) (pulse * 3);
        for (int r = 0; r < HEART.length; r++)
            for (int c2 = 0; c2 < 7; c2++)
                if (HEART[r].charAt(c2) == '1')
                    Gfx.rect(g, hx + c2 * cell, hy + r * cell, cell, cell, Gfx.argb(op, Gfx.mix(col, 0xFFFFFF, 0.1f + 0.25f * pulse)));
    }
}
