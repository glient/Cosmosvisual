package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Arrow around the crosshair pointing at whoever just hurt us.
 * The client does not know the damage source, so the attacker is the nearest living entity within 10 blocks (players first).
 */
public class AttackDirectionModule implements PulseModule {
    private record Hit(double worldYaw, long time) {}
    private final List<Hit> hits = new ArrayList<>();
    private int prevHurt;

    @Override
    public void tick(MinecraftClient c) {
        var p = c.player;
        if (p == null || c.world == null) return;
        if (p.hurtTime > prevHurt && Pulse.on("attack_direction")) {
            Entity best = null;
            double bestD = 100; // 10 blocks squared
            for (Entity e : c.world.getOtherEntities(p, p.getBoundingBox().expand(10), x -> x instanceof LivingEntity)) {
                double d = e.squaredDistanceTo(p) * (e instanceof PlayerEntity ? 1.0 : 2.5); // prefer players
                if (d < bestD) { bestD = d; best = e; }
            }
            if (best != null) {
                double dx = best.getX() - p.getX(), dz = best.getZ() - p.getZ();
                double yaw = Math.toDegrees(Math.atan2(-dx, dz)); // minecraft yaw convention
                hits.add(new Hit(yaw, System.currentTimeMillis()));
            }
        }
        prevHurt = p.hurtTime;
    }

    @Override
    public void hud(DrawContext g, float delta) {
        if (hits.isEmpty()) return;
        var p = Pulse.mc().player;
        float life = Pulse.v("attack_direction", "life") * 1000f;
        float size = Pulse.v("attack_direction", "size");
        float op = Pulse.v("attack_direction", "opacity");
        int col = Pulse.color("attack_direction");
        long now = System.currentTimeMillis();
        float cx = g.getScaledWindowWidth() / 2f, cy = g.getScaledWindowHeight() / 2f;
        float yaw = p.getYaw(delta); // interpolated, smooth while turning
        var m = g.getMatrices();
        for (Hit h : new ArrayList<>(hits)) {
            float age = now - h.time();
            if (age > life) { hits.remove(h); continue; }
            float al = Math.min(Anim.clamp(age / 80f), Anim.clamp((life - age) / 350f)) * op;
            float rel = net.minecraft.util.math.MathHelper.wrapDegrees((float) h.worldYaw() - yaw);
            m.pushMatrix();
            m.translate(cx, cy);
            m.rotate((float) Math.toRadians(rel));
            m.scale(size, size);
            int r = 38;
            for (int i = 0; i < 8; i++) {                      // triangle, tip pointing away from the crosshair
                int y = -r - 8 + i;
                g.fill(-i, y, i + 1, y + 1, Gfx.argb(al, col));
            }
            g.fill(-1, -r, 2, -r + 5, Gfx.argb(al * 0.8f, col));
            m.popMatrix();
        }
    }

    @Override
    public void reset() { hits.clear(); }
}
