package dev.pulse.visuals.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;

public final class Sfx {
    public static void play(SoundEvent ev, float pitch, float volume) {
        if (volume <= 0f) return;
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ev, pitch, volume));
    }
    private Sfx() {}
}
