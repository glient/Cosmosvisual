package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import dev.pulse.visuals.util.Anim;
import dev.pulse.visuals.util.Gfx;
import net.minecraft.client.gui.DrawContext;

/** "x5 HITS" streak. Resets after the lifetime, or when you get hit. */
public class HitCounterModule implements PulseModule {
    private float a;
    private int shownCombo;

    @Override
    public void hud(DrawContext g, float delta) {
        boolean show = Pulse.on("hit_counter") && CombatEvents.combo > 0;
        a = Anim.step(a, show ? 1f : 0f, Pulse.dt * 6f);
        if (CombatEvents.combo > 0) shownCombo = CombatEvents.combo;
        if (a <= 0.02f) return;
        float size = Pulse.v("hit_counter", "size");
        int col = Pulse.color("hit_counter");
        float since = (System.currentTimeMillis() - CombatEvents.lastHitMs) / 1000f;
        float pop = 1f + 0.35f * (1f - Anim.clamp(since / 0.18f));
        String s = "x" + shownCombo + " HITS";
        float sc = size * pop;
        float w = Gfx.tw(s) * sc;
        float x = (g.getScaledWindowWidth() - w) * Pulse.v("hit_counter", "x") / 100f;
        float y = (g.getScaledWindowHeight() - 9 * sc) * Pulse.v("hit_counter", "y") / 100f;
        Gfx.stext(g, s, x, y, sc, Gfx.argb(a, col));
    }
}
