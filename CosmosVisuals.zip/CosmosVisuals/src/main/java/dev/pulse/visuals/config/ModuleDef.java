package dev.pulse.visuals.config;

import java.util.ArrayList;
import java.util.List;

/** Static description of one module: used by the menu to build toggles, sliders and the colour picker. */
public final class ModuleDef {
    public enum Tab {
        TARGET("Target"), SELF("Self"), COMBAT("Combat"), MISC("Misc"), BINDS("Binds"), TRAINING("Training");
        public final String title;
        Tab(String title) { this.title = title; }
    }

    public record Slider(String key, String label, float min, float max, float def, boolean integer) {}

    public final String id;
    public final String name;
    public final Tab tab;
    public boolean defEnabled = true;
    public boolean hasColor = false;
    public int defColor = 0x9B6BFF;
    public final List<Slider> sliders = new ArrayList<>();

    private ModuleDef(String id, String name, Tab tab) {
        this.id = id;
        this.name = name;
        this.tab = tab;
    }

    public static ModuleDef of(String id, String name, Tab tab) { return new ModuleDef(id, name, tab); }
    public ModuleDef off() { defEnabled = false; return this; }
    public ModuleDef color(int rgb) { hasColor = true; defColor = rgb; return this; }
    public ModuleDef f(String key, String label, float min, float max, float def) {
        sliders.add(new Slider(key, label, min, max, def, false));
        return this;
    }
    public ModuleDef i(String key, String label, int min, int max, int def) {
        sliders.add(new Slider(key, label, min, max, def, true));
        return this;
    }
}
