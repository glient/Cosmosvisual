package dev.pulse.visuals.module;

import dev.pulse.visuals.Pulse;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/**
 * Fullbright via a client-side infinite Night Vision effect (no mixin, nothing is sent to the server).
 * We only ever remove the effect if we added it ourselves.
 */
public class FullbrightModule implements PulseModule {
    private boolean applied;

    @Override
    public void tick(MinecraftClient c) {
        var p = c.player;
        if (p == null) { applied = false; return; }
        boolean want = Pulse.on("fullbright");
        if (want) {
            if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, StatusEffectInstance.INFINITE, 0, false, false, false));
                applied = true;
            }
        } else if (applied) {
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur != null && cur.isInfinite()) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            applied = false;
        }
    }

    @Override
    public void reset() { applied = false; }
}
