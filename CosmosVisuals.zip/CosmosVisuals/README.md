# Cosmos Visuals (Fabric, Minecraft 1.21.11, client only)

Menu: **Right Shift**. Zoom: hold **C** (rebindable in Controls). Config: `config/pulsevisuals.json`.

## Build the jar
Requirements: JDK 21, internet (Gradle downloads Minecraft + mappings).

1. Open this folder in IntelliJ IDEA (it imports Gradle automatically), **or** in a terminal run once:
   `gradle wrapper --gradle-version 9.2.1`  (then use `./gradlew`; on Windows `gradlew.bat`).
2. `./gradlew build`
3. The mod is `build/libs/cosmosvisuals-1.0.0.jar` (not the `-sources` one). Put it in `.minecraft/mods` together with Fabric API.
4. Test without installing: `./gradlew runClient`.

If a version in `gradle.properties` does not exist, take the current 1.21.11 numbers from https://fabricmc.net/develop.

## If the build fails with "cannot find symbol"
The code was written against Yarn 1.21.11 from documentation, not compiled. Likely spots:
- `util/WorldDraw.java`: `camera().getCameraPos()` (older: `getPos()`), `RenderLayer.getLines()`, `VertexRendering.drawBox(...)`
- `PulseVisualsClient.java`: `HudRenderCallback` (deprecated; replacement is `HudElementRegistry.addLast(...)`)
- `gui/PulseScreen.java`: `Click` / `KeyInput` input classes (1.21.9+ names), `renderBackground`
- `module/HitParticlesModule.java`: `addParticleClient`
- `bind/KeybindManager.java`: `getBoundKeyTranslationKey()`, `options.allKeys`
Send the compiler log and each error is a one-line fix.

## What is not exactly what you might expect
- Blur strength = vanilla "Menu Background Blurriness" option (Video Settings).
- Damage numbers float up from the crosshair (screen space), not from the target's body.
- Hitbox/outline "thickness" draws several nested boxes.
- Fullbright = client-side Night Vision (nothing sent to the server).
- Screen Stretch is a mixin on the projection matrix with `require = 0`; if the method moved in this build it silently does nothing.
- Binds: in `Hold` mode a command/message is sent once on press; Hold restores the previous state on release only for feature toggles and hotbar slots. `Toggle` only differs from `Press` for feature toggles.
- Kill Aura is intentionally not included.
- Internal mod id and config file name stay `pulsevisuals` (config/pulsevisuals.json); everything the player sees says Cosmos Visuals.
